export const toolboxDesafio1 = {
  kind: 'flyoutToolbox',
  contents: [
    {
      kind: 'block',
      type: 'encerled'
    }
  ]
}
