export const toolboxDesafio2 = {
  kind: 'flyoutToolbox',
  contents: [
    {
      kind: 'block',
      type: 'encerled'
    },
    {
      kind: 'block',
      type: 'apagarled'
    }
  ]
}
